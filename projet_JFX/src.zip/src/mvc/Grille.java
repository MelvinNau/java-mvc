/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc;

/**
 *
 * @author mello
 */
public class Grille {
    protected int x;
    protected int y;
    protected Case[][] grille;
    
    
    public Grille(int _x, int _y){
        grille = new Case[_x][_y];
        this.x = _x;
        this.y = _y;
        for (int i = 0; i < this.x ; i++){
            for (int j = 0 ; j < this.y ; j++){
                this.grille[i][j] = new Case(i, j);
            }
        }
    }
    
    public void afficher(){
        for (int i = 0; i < this.x ; i++){
            for (int j = 0 ; j < this.y ; j++){
                System.out.print(grille[i][j].etat);
            }
            System.out.println();
        }
    }
}
