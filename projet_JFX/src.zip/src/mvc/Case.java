/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mvc;

/**
 *
 * @author mello
 */
public class Case {
    protected int x;
    protected int y;
    protected String etat;
    
    public Case(int _x, int _y){
        this.x = _x;
        this.y = _y;
        this.etat = "R";
    }

    public void setEtat(String symbole){
        this.etat = symbole;
    }
    
    public String getEtat(){
        return this.etat;
    }
    
    
}
